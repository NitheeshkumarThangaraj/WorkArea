﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxAndWhiskerSeries
{
    public class BoxAndWhiskerViewModel
    {
       
        public ObservableCollection<BoxAndWhiskerModel> BoxAndWhiskerData { get; set; }
        public BoxAndWhiskerViewModel()
        {
            BoxAndWhiskerData = new ObservableCollection<BoxAndWhiskerModel>();

            BoxAndWhiskerData.Add(new BoxAndWhiskerModel() { Subject = "Tamil", Marks = new List<double> { -40, -60, 50, 55, 60, 66, 70, 75 }, Number = -30 });
            BoxAndWhiskerData.Add(new BoxAndWhiskerModel() { Subject = "English", Marks = new List<double> { -50, -77, 86, 88, 89, 90, 93, 70 }, Number = -50 });
            BoxAndWhiskerData.Add(new BoxAndWhiskerModel() { Subject = "Maths", Marks = new List<double> { -65, -30, 60, 79, 77, 55, 42, 90 }, Number = 45 });
            BoxAndWhiskerData.Add(new BoxAndWhiskerModel() { Subject = "Social", Marks = new List<double> { -33, -45, 75, 70, 88, 49, 60, 55 }, Number = 60 });

        }


    }
}
