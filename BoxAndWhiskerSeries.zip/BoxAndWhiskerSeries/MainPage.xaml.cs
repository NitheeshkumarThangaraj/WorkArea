﻿
using System.Collections.ObjectModel;

namespace BoxAndWhiskerSeries;

public partial class MainPage : ContentPage
{

   

    public MainPage()
    {
        InitializeComponent();  

    }

    public ObservableCollection<BoxAndWhiskerModel> Data { get; set; }


    private void Button_Clicked(object sender, EventArgs e)
    {
        BoxSeries.StrokeWidth = 3;
        BoxSeries.Spacing = 0.7;
    }

    private void RedColor_Clicked(object sender, EventArgs e)
    {
        BoxSeries.StrokeColor = Brush.Red;

    }
    private void BlueColor_Clicked(object sender, EventArgs e)
    {
        BoxSeries.StrokeColor = Brush.Blue;
    }
    private void Button_Clicked_1(object sender, EventArgs e)
    {
        Data = new ObservableCollection<BoxAndWhiskerModel>();

        Data.Add(new BoxAndWhiskerModel() { Subject = "Tamil", Marks = new List<double> { 80, 70, 75, 60, 90, 80 }, Number = 10 });
        Data.Add(new BoxAndWhiskerModel() { Subject = "English", Marks = new List<double> { 86, 88, 89, 90, 93, 70 }, Number = 20 });
        Data.Add(new BoxAndWhiskerModel() { Subject = "Maths", Marks = new List<double> { 60, 79, 77, 55, 42, 90 }, Number = 50 });

        BoxSeries.ItemsSource = Data;
        


    }
    private void Button_Clicked_2(object sender, EventArgs e)
    {
        
        Data.Clear();
    }

    private void Button_Clicked_3(object sender, EventArgs e)
    {
       
        Data.Insert(2, new BoxAndWhiskerModel() { Subject = "Biology", Marks = new List<double> { 35, 45, 55, 65, 75, 85 } });
        

    }

    

  
    
}
      


