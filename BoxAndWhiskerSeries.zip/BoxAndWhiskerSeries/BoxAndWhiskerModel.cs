﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxAndWhiskerSeries
{
    public class BoxAndWhiskerModel
    {
        public string Subject { get; set; }
        public List<double> Marks { get; set; }
        public double Number { get; set; }
    }
}
